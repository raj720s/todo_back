global.port = 3500
global.host = 'localhost'
// global.database = 'todokdx'
// global.password = ''
// global.user = 'root'
// global.db_port = 3306
// global.db_name = 'todokdx'
// global.db_client = 'mysql'

global.development_db = {
    client: 'mysql2',
    connection: {
        host: 'localhost',
        user: 'root',
        password: '123456',
        database: 'todo',
    }
}